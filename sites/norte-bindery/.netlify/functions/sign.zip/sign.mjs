
import {createRequire as ___nfyCreateRequire} from "module";
import {fileURLToPath as ___nfyFileURLToPath} from "url";
import {dirname as ___nfyPathDirname} from "path";
let __filename=___nfyFileURLToPath(import.meta.url);
let __dirname=___nfyPathDirname(___nfyFileURLToPath(import.meta.url));
let require=___nfyCreateRequire(import.meta.url);


// netlify/functions/sign.mjs
var config = { path: "/api/sign" };
var enc = new TextEncoder();
var b64url = (buf) => Buffer.from(buf).toString("base64").replace(/\+/g, "-").replace(/\//g, "_").replace(/=+$/, "");
var json = (body, status, headers) => new Response(JSON.stringify(body), { status, headers: { "content-type": "application/json", ...headers } });
var sign_default = async (req) => {
  const origin = new URL(req.url).origin;
  const cors = { "Access-Control-Allow-Origin": origin, "Access-Control-Allow-Methods": "POST, OPTIONS", "Access-Control-Allow-Headers": "content-type", "Cache-Control": "no-store" };
  if (req.method === "OPTIONS") return new Response(null, { status: 204, headers: cors });
  if (req.method !== "POST") return json({ error: "POST only" }, 405, cors);
  const raw = process.env.BATON_PRIVATE_JWK;
  if (!raw) return json({ error: "BATON_PRIVATE_JWK is not set on this site, so it cannot sign legs." }, 500, cors);
  let body;
  try {
    body = await req.json();
  } catch {
    return json({ error: "Body must be JSON: { payload, kid }" }, 400, cors);
  }
  if (typeof body?.payload !== "string" || body.payload.length === 0) return json({ error: "payload must be a non-empty string" }, 400, cors);
  let jwk;
  try {
    jwk = JSON.parse(raw);
  } catch {
    return json({ error: "BATON_PRIVATE_JWK is not valid JSON" }, 500, cors);
  }
  if (body.kid && jwk.kid && body.kid !== jwk.kid) return json({ error: "kid mismatch; this origin signs as " + jwk.kid }, 400, cors);
  const key = await crypto.subtle.importKey("jwk", jwk, { name: "ECDSA", namedCurve: "P-256" }, false, ["sign"]);
  const sig = await crypto.subtle.sign({ name: "ECDSA", hash: "SHA-256" }, key, enc.encode(body.payload));
  return json({ sig: b64url(sig), kid: jwk.kid }, 200, cors);
};
export {
  config,
  sign_default as default
};
